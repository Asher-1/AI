# XOR

To prove that linear model can't fit XOR and nonlinear model can fit XOR. Code is [here](https://github.com/hjptriplebee/Deep_learning_model/tree/master/chapter_06/6_1_XOR)

output of XOR.py 

<p align="center">
<img src="https://raw.githubusercontent.com/hjptriplebee/Deep_learning_model/master/img/6-1-XOR1.jpeg" width="45%">
</p>

output of XORV2.py

<p align="center">
<img src="https://raw.githubusercontent.com/hjptriplebee/Deep_learning_model/master/img/6-1-XOR2.jpeg" width="45%">
</p>
 
