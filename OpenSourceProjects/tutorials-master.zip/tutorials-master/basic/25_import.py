# View more python learning tutorial on my Youtube and Youku channel!!!

# Youtube video tutorial: https://www.youtube.com/channel/UCdyjiB5H8Pu7aDTNVXTTpcg
# Youku video tutorial: http://i.youku.com/pythontutorial

import time
print(time.localtime())

import time as t
print(t.localtime())

from time import localtime, time
print(localtime())
print(time())

from time import *
print(localtime())
